:mod:`message` -- Tools for creating messages to be sent to MongoDB
===================================================================

.. automodule:: pymongo.message
   :synopsis: Tools for creating messages to be sent to MongoDB
   :members:
